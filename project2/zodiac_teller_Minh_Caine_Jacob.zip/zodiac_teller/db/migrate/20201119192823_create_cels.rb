class CreateCels < ActiveRecord::Migration[6.0]
  def change
    create_table :cels do |t|
      t.string :name
      t.date :birthday
      t.text :description

      t.timestamps
    end
  end
end
