module UsersHelper
    def checkZodiacSign(user)
        if (user.birthday.month == 12)
            if (user.birthday.day < 22) 
            astro_sign = "sagittarius" 
            else
            astro_sign = "capricorn" 
            end
        elsif (user.birthday.month == 1)
            if (user.birthday.day < 20) 
            astro_sign = "capricorn" 
            else
            astro_sign = "aquarius" 
            end 
        elsif (user.birthday.month == 2) 
            if (user.birthday.day < 19) 
            astro_sign = "aquarius" 
            else
            astro_sign = "pisces"
            end
        elsif(user.birthday.month == 3)
            if (user.birthday.day < 21)  
            astro_sign = "pisces" 
            else
            astro_sign = "aries" 
            end 
        elsif (user.birthday.month == 4)
            if (user.birthday.day < 20) 
            astro_sign = "aries" 
            else
            astro_sign = "taurus"
            end 
        elsif (user.birthday.month == 5)
            if (user.birthday.day < 21) 
            astro_sign = "taurus" 
            else
            astro_sign = "gemini"
            end 
        elsif(user.birthday.month == 6)
            if (user.birthday.day < 21) 
            astro_sign = "gemini"
            else
            astro_sign = "cancer" 
            end
        elsif (user.birthday.month == 7)
            if (user.birthday.day < 23) 
            astro_sign = "cancer"
            else
            astro_sign = "leo" 
            end 
        elsif( user.birthday.month == 8) 
            if (user.birthday.day < 23)  
            astro_sign = "leo" 
            else
            astro_sign = "virgo" 
            end 
        elsif (user.birthday.month == 9)
            if (user.birthday.day < 23) 
            astro_sign = "virgo" 
            else
            astro_sign = "libra" 
            end 
        elsif (user.birthday.month == 10)
            if (user.birthday.day < 23) 
            astro_sign = "libra" 
            else
            astro_sign = "scorpio" 
            end
        elsif (user.birthday.month == 11)
            if (user.birthday.day < 22) 
            astro_sign = "scorpio" 
            else
            astro_sign = "sagittarius" 
            end
        end
        astro_sign
    end
end
