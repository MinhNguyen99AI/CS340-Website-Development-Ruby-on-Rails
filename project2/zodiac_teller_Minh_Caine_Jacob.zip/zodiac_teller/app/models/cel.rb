class Cel < ApplicationRecord
end
