class PageController < ApplicationController
  def homepage
    @user = User.new
  end
  def show
  end
  
end
