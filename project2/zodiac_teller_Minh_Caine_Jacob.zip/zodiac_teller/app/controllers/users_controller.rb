class UsersController < ApplicationController
  include UsersHelper
  def new
    @user = User.new
  end

  def show
    @c = Cel.all
    #if @user.zodiacsign.eql?'aries'
    render 'show'
    #else render 'show'
   # end
  end 
  
  def create
    @c = Cel.all
    @u = User.all
    ariesRange = Date.new(2020,03,21)..Date.new(2020,04,19)
    geminiRange = Date.new(2020,05,21)..Date.new(2020,06,20)
    cancerRange = Date.new(2020,06,21)..Date.new(2020,07,22)
    leoRange = Date.new(2020,07,23)..Date.new(2020,8,22)
    virgoRange = Date.new(2020,8,23)..Date.new(2020,9,22)
    libraRange = Date.new(2020,9,23)..Date.new(2020,10,22)
    scorpioRange = Date.new(2020,10,23)..Date.new(2020,11,21)
    sagittariusRange = Date.new(2020,11,22)..Date.new(2020,12,21)
    capricornRange1 = Date.new(2020,12,22)..Date.new(2020,12,31) 
    capricornRange2 = Date.new(2020,01,01)..Date.new(2020,01,19) 
    aquariusRange = Date.new(2020,01,20)..Date.new(2020,02,18)
    piscesRange = Date.new(2020,02,19)..Date.new(2020,03,20)
    taurusRange =Date.new(2020,04,21)..Date.new(2020,05,19)
    @user = User.new(user_params)
    if @user.save
      flash[:success] = "Success"
      @user.birthday = @user.birthday.change(year: 2020)
      if ariesRange.cover?@user.birthday
        #@user.zodiacsign = 'aries''
        render "aries"
      elsif taurusRange.cover?@user.birthday
        render "taurus"
      elsif geminiRange.cover?@user.birthday
        render "gemini"
      elsif cancerRange.cover?@user.birthday
        render "cancer"
      elsif leoRange.cover?@user.birthday
        render "leo"
      elsif virgoRange.cover?@user.birthday
        render "virgo"
      elsif libraRange.cover?@user.birthday
        render "libra"
      elsif scorpioRange.cover?@user.birthday
        render "scorpio"
      elsif (capricornRange1.cover?@user.birthday) || (capricornRange2.cover?@user.birthday)
        render "capricorn"
      elsif sagittariusRange.cover?@user.birthday
        render "sagittarius"
      elsif aquariusRange.cover?@user.birthday
        render "aquarius"
      elsif piscesRange.cover?@user.birthday
        render "pisces"
      else
        render "show"
      end
    else
      
      render 'new'
    end
  end
  private
  def user_params
    params.require(:user).permit(:name,:birthday)
  end
  def aries
     @c = Cel.all 
  end

  def taurus
     @c = Cel.all 
  end

  def gemini
     @c = Cel.all
  end

  def cancer
     @c = Cel.all 
  end

  def leo
    @c = Cel.all
  end

  def virgo
    @c = Cel.all 
  end

  def libra
    @c = Cel.all
  end

  def scorpio
     @c = Cel.all
  end

  def sagittarius
     @c = Cel.all #added this to all signs. (It was only in libra)
  end

  def capricorn
     @c = Cel.all
  end

  def aquarius
     @c = Cel.all
  end

  def pisces
     @c = Cel.all
  end
end
