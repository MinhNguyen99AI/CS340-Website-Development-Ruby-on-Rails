require "application_system_test_case"

class CelebsTest < ApplicationSystemTestCase
  setup do
    @celeb = celebs(:one)
  end

  test "visiting the index" do
    visit celebs_url
    assert_selector "h1", text: "Celebs"
  end

  test "creating a Celeb" do
    visit celebs_url
    click_on "New Celeb"

    fill_in "Birthday", with: @celeb.birthday
    fill_in "Description", with: @celeb.description
    fill_in "Name", with: @celeb.name
    click_on "Create Celeb"

    assert_text "Celeb was successfully created"
    click_on "Back"
  end

  test "updating a Celeb" do
    visit celebs_url
    click_on "Edit", match: :first

    fill_in "Birthday", with: @celeb.birthday
    fill_in "Description", with: @celeb.description
    fill_in "Name", with: @celeb.name
    click_on "Update Celeb"

    assert_text "Celeb was successfully updated"
    click_on "Back"
  end

  test "destroying a Celeb" do
    visit celebs_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Celeb was successfully destroyed"
  end
end
