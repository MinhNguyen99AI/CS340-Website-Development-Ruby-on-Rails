require 'test_helper'

class PageControllerTest < ActionDispatch::IntegrationTest
  test "should get homepage" do
    get page_homepage_url
    assert_response :success
  end

  test "should get aries" do
    get page_aries_url
    assert_response :success
  end

  test "should get taurus" do
    get page_taurus_url
    assert_response :success
  end

  test "should get gemini" do
    get page_gemini_url
    assert_response :success
  end

  test "should get cancer" do
    get page_cancer_url
    assert_response :success
  end

  test "should get leo" do
    get page_leo_url
    assert_response :success
  end

  test "should get virgo" do
    get page_virgo_url
    assert_response :success
  end

  test "should get libra" do
    get page_libra_url
    assert_response :success
  end

  test "should get scorpio" do
    get page_scorpio_url
    assert_response :success
  end

  test "should get sagittarius" do
    get page_sagittarius_url
    assert_response :success
  end

  test "should get capricorn" do
    get page_capricorn_url
    assert_response :success
  end

  test "should get aquarius" do
    get page_aquarius_url
    assert_response :success
  end

  test "should get pisces" do
    get page_pisces_url
    assert_response :success
  end

end
