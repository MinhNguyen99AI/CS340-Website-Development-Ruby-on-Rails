require 'test_helper'

class CelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
