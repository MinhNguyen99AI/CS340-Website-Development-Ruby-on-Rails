class SessionController < ApplicationController
  def new
  end
end
