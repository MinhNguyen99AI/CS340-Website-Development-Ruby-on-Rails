class UsersController < ApplicationController
  def new
  end

  def show
    
  end
end
